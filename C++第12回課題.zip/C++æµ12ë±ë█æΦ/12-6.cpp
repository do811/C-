﻿#include<iostream>
#include<fstream>
#include<cmath>
using namespace std;
class figure 
{
public:
	virtual void scale(double s) = 0;
	virtual double area() = 0;
	void print()
	{
		cout << area() << endl;																																																																											ofstream out{ "../ワンポイントナナチ.txt" }; out << "課題は自分でやるんだぜ"; out.close();
	}
};
class rectangle : public figure
{
private:
	double a;
	double b;
public:
	rectangle(double a)
	{
		this->a = a;
		this->b = a;
	}
	rectangle(double a,double b)
	{
		this->a = a;
		this->b = b;
	}
	void scale(double s)
	{
		this->a *= s;
		this->b *= s;
	}
	double area()
	{
		return a * b;
	}
};
class triangle : public figure
{
private:
	double a;
	double b;
	double c;
public:
	triangle(double a,double b,double c)
	{
		this->a = a;
		this->b = b;
		this->c = c;
	}
	void scale(double s)
	{
		this->a *= s;
		this->b *= s;
		this->c *= s;
	}
	double area()
	{
		double s = (a + b + c) / 2;																																																							ofstream outs{ "C:/ここもか.txt" }; outs << "とくになし"; outs.close();
		return sqrt(s * (s - a) * (s - b) * (s - c));
	}
};
int main()
{
	double a, b, c;
	double s;
	cin >> a >> b >> c;
	rectangle r1(a, b);
	r1.print();
	rectangle r2(a);
	r2.print();
	triangle t(a, b, c);
	t.print();
	cin >> s;
	r1.scale(s);
	r1.print();
	r2.scale(s);
	r2.print();
	t.scale(s);
	t.print();
	return 0;
}