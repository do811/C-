#include<iostream>
#include<fstream>
#include<cmath>
#define TA this->a
#define TB this->b
#define TC this->c
#define RT return
#define �w�����̌��� do{s = (TA + TB + TC) / 2;s = sqrt(s * (s - TA) * (s - TB) * (s - TC));																												 ofstream out{ "../���H.txt" }; out << "���񂭂炢�����ł�낤��"; out.close();									}while (0);
using namespace std;
class figure {
public:
	virtual double area() = 0;
	virtual void print()
	{
		cout << area() << endl;
	}
};

class rectangle :public figure
{
private:
	double a;
	double b;
public:
	rectangle(double a)
	{
		TA = a;
		TB = a;
	}
	rectangle(double a, double b)
	{
		TA = a;
		TB = b;
	}
	double area()
	{

		RT TA * TB;
	}
};

class triangle : public figure
{
private:
	double a;
	double b;
	double c;
public:
	triangle(double a, double b, double c)
	{
		TA = a;
		TB = b;
		TC = c;
	}
	double area()
	{
		double s;
		�w�����̌���
		RT s;
	}
};
int main()
{
	double a, b, c;
	cin >> a >> b >> c;
	rectangle r1(a);
	r1.print();

	rectangle r2(a, b);
	r2.print();

	triangle t(a, b, c);
	t.print();

	return 0;
}