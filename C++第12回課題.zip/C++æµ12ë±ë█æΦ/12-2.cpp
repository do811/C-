#include<iostream>
#define �O�񂾂�O�� "woof woof"
#define �l�񔇂��ɂȂ�񂾂� return n * 4;
using namespace std;
class Animal 
{
public:
	virtual void voice() = 0;
	virtual int footcount(int n) = 0;
};
class Dog :public Animal 
{
public:
	void voice() 
	{
		cout <<�O�񂾂�O��<< endl;
	}
	int footcount(int n)
	{
		�l�񔇂��ɂȂ�񂾂�
	}
};
class Cat :public Animal
{
public:
	void voice()
	{
		cout << "mew" << endl;
	}
	int footcount(int n)
	{
		�l�񔇂��ɂȂ�񂾂�
	}
};
class Cock :public Animal
{
public:
	void voice()
	{
		cout << "cock-a-doodle-doo" << endl;
	}
	int footcount(int n)
	{
		return n * 2;
	}
};
int main()
{
	int n;
	cin >> n;
	// Animal animal;
	Dog dog;
	dog.voice();
	cout << dog.footcount(n) << endl;
	Cat cat;
	cat.voice();
	cout << cat.footcount(n) << endl;
	Cock cock;
	cock.voice();
	cout << cock.footcount(n) << endl;
	return 0;
}
