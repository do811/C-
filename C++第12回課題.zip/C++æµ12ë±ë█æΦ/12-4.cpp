#include<iostream>
using namespace std;
class factorial {
private:
	static int count;
public:
	static int get() {
		return count;
	}
	int fact(int n) {
		count++;
		if (n == 0)
		{
			return 1;
		}
		return n * fact(n - 1);
	}
	factorial() {
		count = 0;
	}
};
int factorial::count;
int main()
{
	factorial f1, f2;
	int n;
	cin >> n;
	cout << f1.fact(n) << endl;
	cout << f1.get() << endl;
	cout << f2.fact(n + 1) << endl;
	cout << f2.get() << endl;
	return 0;
}
